package it.codegen.training.SunTravels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SunTravelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
