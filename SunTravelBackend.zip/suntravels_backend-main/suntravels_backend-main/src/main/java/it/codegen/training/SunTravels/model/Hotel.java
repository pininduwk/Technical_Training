/*
 * Copyright (c) 2023. CodeGen International (Pvt) Ltd. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of CodeGen
 * International (Pvt) Ltd. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with CodeGen International.
 *
 */
package it.codegen.training.SunTravels.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;



@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table( name = "JPA_HOTEL" )
public class Hotel implements Serializable
{
    @Id
    @SequenceGenerator( name = "jpa_hotel_sequence", sequenceName = "jpa_hotel_sequence", allocationSize = 1

    )
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "jpa_hotel_sequence"

    )
    @Column( nullable = false, updatable = false, name = "hotelId" )
    private long hotelId;
    private String hotelName;
    private String city;
    private String phoneNumber;

    //    @JsonIgnore
    @OneToMany( cascade = CascadeType.ALL, mappedBy = "hotel" )
    private List<Contract> contract;


    @OneToMany( cascade = CascadeType.ALL, mappedBy = "hotel")
    private List<Rooms> rooms;
}





















